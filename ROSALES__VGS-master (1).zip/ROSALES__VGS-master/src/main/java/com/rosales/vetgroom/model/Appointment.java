package com.rosales.vetgroom.model;

/** Read-only view of an appointment joined with its owner's name (Java Record). */
public record Appointment(int appointmentId,
                          String ownerName,
                          String petName,
                          String serviceType,
                          String appointmentDate,
                          String appointmentTime,
                          String status) { }
