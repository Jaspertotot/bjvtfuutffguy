package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.model.Appointment;

import java.util.List;

/** Shared console table for appointment lists. */
final class AppointmentTable {

    private AppointmentTable() { }

    static void print(List<Appointment> list) {
        if (list.isEmpty()) {
            System.out.println("No appointments found.");
            return;
        }
        String fmt = "| %-4s | %-18s | %-12s | %-11s | %-10s | %-5s | %-11s |%n";
        String border = "+------+--------------------+--------------+-------------+------------+-------+-------------+";
        System.out.println(border);
        System.out.printf(fmt, "ID", "OWNER", "PET", "SERVICE", "DATE", "TIME", "STATUS");
        System.out.println(border);
        for (Appointment a : list) {
            System.out.printf(fmt, a.appointmentId(), cut(a.ownerName(), 18), cut(a.petName(), 12),
                    a.serviceType(), a.appointmentDate(), a.appointmentTime(), a.status());
        }
        System.out.println(border);
    }

    private static String cut(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
