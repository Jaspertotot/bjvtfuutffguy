package com.rosales.vetgroom.model;

/** Immutable user account (Java Record). */
public record User(int userId,
                   String username,
                   String passwordHash,
                   String fullName,
                   String email,
                   Role role,
                   String accountStatus) {

    /** Convenience constructor for a brand-new registration (id assigned by the database, status PENDING). */
    public User(String username, String passwordHash, String fullName, String email, Role role) {
        this(0, username, passwordHash, fullName, email, role, "PENDING");
    }
}
