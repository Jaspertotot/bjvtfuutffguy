package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.dao.AppointmentDao;
import com.rosales.vetgroom.model.User;
import com.rosales.vetgroom.util.InputHelper;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class PetOwnerMenu {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    private final AppointmentDao appointmentDao;
    private final Scanner scanner;
    private final User currentUser;

    public PetOwnerMenu(AppointmentDao appointmentDao, Scanner scanner, User currentUser) {
        this.appointmentDao = appointmentDao;
        this.scanner = scanner;
        this.currentUser = currentUser;
    }

    public void show() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== PET OWNER MENU ===");
            System.out.println("  1. Request Appointment");
            System.out.println("  2. View My Appointments");
            System.out.println("  0. Logout");
            System.out.print("Choose: ");

            switch (scanner.nextLine().trim()) {
                case "1": requestAppointment(); break;
                case "2":
                    System.out.println("\n--- MY APPOINTMENTS ---");
                    AppointmentTable.print(appointmentDao.getAppointmentsByOwner(currentUser));
                    break;
                case "0": running = false; System.out.println("Logged out."); break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private void requestAppointment() {
        System.out.println("\n--- REQUEST APPOINTMENT ---");
        String serviceType = null;
        while (serviceType == null) {
            System.out.println("  1. VETERINARY");
            System.out.println("  2. GROOMING");
            int choice = InputHelper.readInt(scanner, "Service type (0 to cancel): ");
            if (choice == 0) {
                System.out.println("Request cancelled.");
                return;
            }
            if (choice == 1) serviceType = "VETERINARY";
            else if (choice == 2) serviceType = "GROOMING";
            else System.out.println("Invalid choice.");
        }

        String petName = InputHelper.readRequired(scanner, "Pet name: ");
        String petType = InputHelper.readRequired(scanner, "Pet type (e.g., Dog, Cat): ");
        System.out.print("Breed (optional): ");
        String petBreed = scanner.nextLine().trim();
        String description = InputHelper.readRequired(scanner, "Service needed (e.g., Check-up, Full groom): ");

        LocalDate date = null;
        while (date == null) {
            System.out.print("Date (yyyy-MM-dd): ");
            try {
                date = LocalDate.parse(scanner.nextLine().trim());
                if (date.isBefore(LocalDate.now())) {
                    System.out.println("Date cannot be in the past.");
                    date = null;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format.");
            }
        }

        LocalTime time = null;
        while (time == null) {
            System.out.print("Time (HH:mm, 24-hour): ");
            try {
                time = LocalTime.parse(scanner.nextLine().trim(), TIME_FORMAT);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid time format.");
            }
        }

        int id = appointmentDao.createAppointment(currentUser, petName, petType, petBreed,
                serviceType, description, date.toString(), time.format(TIME_FORMAT));
        if (id > 0) {
            System.out.println("SUCCESS: Appointment #" + id + " requested. Status: PENDING.");
        } else {
            System.out.println("Could not create the appointment.");
        }
    }
}
