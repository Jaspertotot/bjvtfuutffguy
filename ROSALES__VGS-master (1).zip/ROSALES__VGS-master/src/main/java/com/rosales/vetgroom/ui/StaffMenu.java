package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.dao.AppointmentDao;
import com.rosales.vetgroom.model.Appointment;
import com.rosales.vetgroom.model.User;
import com.rosales.vetgroom.util.InputHelper;

import java.util.List;
import java.util.Scanner;

/** Shared menu for Veterinarian and Groomer; each handles one service type. */
public class StaffMenu {

    private static final String[] STATUSES = {"CONFIRMED", "IN_PROGRESS", "COMPLETED", "CANCELLED"};

    private final AppointmentDao appointmentDao;
    private final Scanner scanner;
    private final User currentUser;
    private final String serviceType;
    private final String title;

    protected StaffMenu(AppointmentDao appointmentDao, Scanner scanner, User currentUser,
                        String serviceType, String title) {
        this.appointmentDao = appointmentDao;
        this.scanner = scanner;
        this.currentUser = currentUser;
        this.serviceType = serviceType;
        this.title = title;
    }

    public void show() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== " + title + " ===");
            System.out.println("  1. View Open Appointments");
            System.out.println("  2. Update Appointment Status");
            System.out.println("  0. Logout");
            System.out.print("Choose: ");

            switch (scanner.nextLine().trim()) {
                case "1":
                    System.out.println("\n--- OPEN " + serviceType + " APPOINTMENTS ---");
                    AppointmentTable.print(appointmentDao.getOpenAppointmentsByService(serviceType));
                    break;
                case "2": updateStatus(); break;
                case "0": running = false; System.out.println("Logged out."); break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private void updateStatus() {
        List<Appointment> open = appointmentDao.getOpenAppointmentsByService(serviceType);
        System.out.println("\n--- UPDATE APPOINTMENT STATUS ---");
        if (open.isEmpty()) {
            System.out.println("No open appointments.");
            return;
        }
        AppointmentTable.print(open);

        int id;
        while (true) {
            id = InputHelper.readInt(scanner, "Enter Appointment ID (0 to cancel): ");
            if (id == 0) {
                System.out.println("Update cancelled.");
                return;
            }
            final int target = id;
            if (open.stream().anyMatch(a -> a.appointmentId() == target)) {
                break;
            }
            System.out.println("Appointment #" + id + " is not in the open list. Try again.");
        }

        String newStatus = null;
        while (newStatus == null) {
            for (int i = 0; i < STATUSES.length; i++) {
                System.out.println("  " + (i + 1) + ". " + STATUSES[i]);
            }
            int choice = InputHelper.readInt(scanner, "New status (0 to cancel): ");
            if (choice == 0) {
                System.out.println("Update cancelled.");
                return;
            }
            if (choice >= 1 && choice <= STATUSES.length) {
                newStatus = STATUSES[choice - 1];
            } else {
                System.out.println("Invalid choice.");
            }
        }

        if (appointmentDao.updateAppointmentStatus(currentUser.userId(), id, newStatus)) {
            System.out.println("SUCCESS: Appointment #" + id + " is now " + newStatus + ".");
        } else {
            System.out.println("Update failed. No changes were saved.");
        }
    }
}
