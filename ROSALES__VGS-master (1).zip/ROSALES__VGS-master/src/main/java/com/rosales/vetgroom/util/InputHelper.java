package com.rosales.vetgroom.util;

import java.util.Scanner;

/** Crash-proof console input helpers. */
public class InputHelper {

    private InputHelper() { }

    /** Keeps asking until a whole number is entered. */
    public static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    /** Keeps asking until a non-blank value is entered. */
    public static String readRequired(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("This field cannot be empty.");
        }
    }
}
