package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.dao.AppointmentDao;
import com.rosales.vetgroom.model.User;

import java.util.Scanner;

public class VeterinarianMenu extends StaffMenu {
    public VeterinarianMenu(AppointmentDao appointmentDao, Scanner scanner, User currentUser) {
        super(appointmentDao, scanner, currentUser, "VETERINARY", "VETERINARIAN MENU");
    }
}
