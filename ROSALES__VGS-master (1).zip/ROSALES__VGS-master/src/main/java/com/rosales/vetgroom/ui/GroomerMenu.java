package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.dao.AppointmentDao;
import com.rosales.vetgroom.model.User;

import java.util.Scanner;

public class GroomerMenu extends StaffMenu {
    public GroomerMenu(AppointmentDao appointmentDao, Scanner scanner, User currentUser) {
        super(appointmentDao, scanner, currentUser, "GROOMING", "GROOMER MENU");
    }
}
