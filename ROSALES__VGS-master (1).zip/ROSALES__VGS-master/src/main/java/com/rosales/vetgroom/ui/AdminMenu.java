package com.rosales.vetgroom.ui;

import com.rosales.vetgroom.dao.ActivityLogDao;
import com.rosales.vetgroom.dao.UserDao;
import com.rosales.vetgroom.model.ActivityLog;
import com.rosales.vetgroom.model.Role;
import com.rosales.vetgroom.model.User;

import java.util.List;
import java.util.Scanner;

/** Administrator menu. All data access goes through UserDao; no SQL here. */
public class AdminMenu {

    private static final String[] VALID_STATUSES = {"APPROVED", "PENDING"};

    private final UserDao userDao;
    private final ActivityLogDao logDao;
    private final Scanner scanner;
    private final User currentUser;

    public AdminMenu(UserDao userDao, ActivityLogDao logDao, Scanner scanner, User currentUser) {
        this.userDao = userDao;
        this.logDao = logDao;
        this.scanner = scanner;
        this.currentUser = currentUser;
    }

    public void show() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== ADMINISTRATOR MENU ===");
            System.out.println("  1. View All System Users");
            System.out.println("  2. View Pending Registrations");
            System.out.println("  3. Approve User Account");
            System.out.println("  4. Update User Role and Status");
            System.out.println("  5. View System Audit Logs");
            System.out.println("  0. Logout");
            System.out.print("Choose: ");

            switch (scanner.nextLine().trim()) {
                case "1": viewAllUsers(); break;
                case "2": viewPendingUsers(); break;
                case "3": approveUserAccount(); break;
                case "4": updateUserRoleAndStatus(); break;
                case "5": auditLogMenu(); break;
                case "0": running = false; System.out.println("Logged out."); break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    // ------------------------------------------------------------------ views

    private void viewAllUsers() {
        System.out.println("\n--- ALL SYSTEM USERS ---");
        printUserTable(userDao.getAllUsers());
    }

    private void viewPendingUsers() {
        System.out.println("\n--- PENDING REGISTRATIONS ---");
        printUserTable(userDao.getPendingUsers());
    }

    // --------------------------------------------------------------- approval

    private void approveUserAccount() {
        List<User> pending = userDao.getPendingUsers();
        System.out.println("\n--- APPROVE USER ACCOUNT ---");
        if (pending.isEmpty()) {
            System.out.println("No pending accounts to approve.");
            return;
        }
        printUserTable(pending);

        while (true) {
            int targetId = readIntInput("Enter Target User ID to approve (0 to cancel): ");
            if (targetId == 0) {
                System.out.println("Approval cancelled.");
                return;
            }
            boolean inPendingList = pending.stream().anyMatch(u -> u.userId() == targetId);
            if (!inPendingList) {
                System.out.println("User ID " + targetId + " is not in the pending list. Try again.");
                continue;
            }
            if (userDao.approveUser(currentUser.userId(), targetId)) {
                System.out.println("SUCCESS: User ID " + targetId + " has been APPROVED.");
            } else {
                System.out.println("Approval failed. The account may no longer be pending.");
            }
            return;
        }
    }

    // ----------------------------------------------------------------- update

    private void updateUserRoleAndStatus() {
        System.out.println("\n--- UPDATE USER ROLE AND STATUS ---");
        List<User> users = userDao.getAllUsers();
        printUserTable(users);

        // Step 1: target user
        User target = null;
        while (target == null) {
            int targetId = readIntInput("Enter Target User ID to update (0 to cancel): ");
            if (targetId == 0) {
                System.out.println("Update cancelled.");
                return;
            }
            if (targetId == currentUser.userId()) {
                System.out.println("WARNING: Modifying the currently active admin account is restricted.");
                return;
            }
            for (User u : users) {
                if (u.userId() == targetId) {
                    target = u;
                    break;
                }
            }
            if (target == null) {
                System.out.println("User ID " + targetId + " does not exist. Try again.");
            }
        }
        System.out.println("Selected: " + target.username()
                + " (role: " + target.role().name() + ", status: " + target.accountStatus() + ")");

        // Step 2: new role
        String newRole = readValidRole();
        if (newRole == null) {
            System.out.println("Update cancelled.");
            return;
        }

        // Step 3: new status
        String newStatus = readValidStatus();
        if (newStatus == null) {
            System.out.println("Update cancelled.");
            return;
        }

        if (userDao.updateUserRoleAndStatus(currentUser.userId(), target.userId(), newRole, newStatus)) {
            System.out.println("SUCCESS: User ID " + target.userId() + " (" + target.username()
                    + ") updated to role " + newRole + ", status " + newStatus + ".");
        } else {
            System.out.println("Update failed. No changes were saved.");
        }
    }

    // -------------------------------------------------------------- audit logs

    private void auditLogMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- SYSTEM AUDIT LOGS ---");
            System.out.println("  1. View All System Logs");
            System.out.println("  2. Filter Logs by User ID");
            System.out.println("  3. Clear All Logs");
            System.out.println("  0. Back");
            System.out.print("Choose: ");

            switch (scanner.nextLine().trim()) {
                case "1": printLogTable(logDao.getAllLogs()); break;
                case "2": filterLogsByUser(); break;
                case "3": clearLogs(); break;
                case "0": back = true; break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private void filterLogsByUser() {
        int userId = readIntInput("Enter User ID to filter (0 to cancel): ");
        if (userId == 0) {
            System.out.println("Filter cancelled.");
            return;
        }
        printLogTable(logDao.getLogsByUserId(userId));
    }

    private void clearLogs() {
        int count = logDao.getAllLogs().size();
        if (count == 0) {
            System.out.println("No logs to clear.");
            return;
        }
        System.out.print("This permanently deletes " + count + " log entries. Type YES to confirm: ");
        if (!scanner.nextLine().trim().equals("YES")) {
            System.out.println("Clear cancelled.");
            return;
        }
        int removed = logDao.clearAllLogs();
        logDao.logAction(currentUser.userId(), "LOGS_CLEARED",
                "Admin " + currentUser.userId() + " cleared " + removed + " log entries.");
        System.out.println("SUCCESS: " + removed + " log entries cleared.");
    }

    /** Aligned audit table. Long descriptions wrap onto extra lines instead of breaking the columns. */
    private void printLogTable(List<ActivityLog> logs) {
        if (logs.isEmpty()) {
            System.out.println("No log entries found.");
            return;
        }
        String fmt = "%-5s | %-8s | %-18s | %-35s | %-20s%n";
        String line = "-".repeat(98);
        System.out.println(line);
        System.out.printf(fmt, "ID", "USER ID", "ACTION TYPE", "DESCRIPTION", "TIMESTAMP");
        System.out.println(line);
        for (ActivityLog log : logs) {
            String text = log.description();
            System.out.printf(fmt, log.id(), log.userId(), log.actionType(),
                    text.length() > 35 ? text.substring(0, 35) : text, log.timestamp());
            for (int i = 35; i < text.length(); i += 35) {
                System.out.printf(fmt, "", "", "", text.substring(i, Math.min(i + 35, text.length())), "");
            }
        }
        System.out.println(line);
        System.out.println(logs.size() + " log entr" + (logs.size() == 1 ? "y." : "ies."));
    }

    // ------------------------------------------------------ validation wrappers

    /** Keeps asking until the person enters a whole number. Never throws on bad input. */
    private int readIntInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    /**
     * Keeps asking until a valid role is entered (name or list number).
     * Returns the role name in upper case, or null if the person enters 0 to cancel.
     */
    private String readValidRole() {
        Role[] roles = Role.values();
        while (true) {
            System.out.println("Valid roles:");
            for (int i = 0; i < roles.length; i++) {
                System.out.println("  " + (i + 1) + ". " + roles[i].name());
            }
            System.out.print("Enter new role (name or number, 0 to cancel): ");
            String input = scanner.nextLine().trim().toUpperCase();

            if (input.equals("0")) {
                return null;
            }
            for (int i = 0; i < roles.length; i++) {
                if (input.equals(roles[i].name()) || input.equals(String.valueOf(i + 1))) {
                    return roles[i].name();
                }
            }
            System.out.println("Invalid role. Please choose from the list.");
        }
    }

    /**
     * Keeps asking until APPROVED or PENDING is entered (name or list number).
     * Returns the status in upper case, or null if the person enters 0 to cancel.
     */
    private String readValidStatus() {
        while (true) {
            System.out.println("Valid statuses:");
            for (int i = 0; i < VALID_STATUSES.length; i++) {
                System.out.println("  " + (i + 1) + ". " + VALID_STATUSES[i]);
            }
            System.out.print("Enter new status (name or number, 0 to cancel): ");
            String input = scanner.nextLine().trim().toUpperCase();

            if (input.equals("0")) {
                return null;
            }
            for (int i = 0; i < VALID_STATUSES.length; i++) {
                if (input.equals(VALID_STATUSES[i]) || input.equals(String.valueOf(i + 1))) {
                    return VALID_STATUSES[i];
                }
            }
            System.out.println("Invalid status. Please choose APPROVED or PENDING.");
        }
    }

    // ------------------------------------------------------------ table helper

    /** Renders any list of users as an aligned, bordered table. */
    private void printUserTable(List<User> users) {
        if (users.isEmpty()) {
            System.out.println("No records found.");
            return;
        }
        String border = "+-------+-----------------+----------------+------------+";
        System.out.println(border);
        System.out.printf("| %-5s | %-15s | %-14s | %-10s |%n", "ID", "USERNAME", "ROLE", "STATUS");
        System.out.println(border);
        for (User u : users) {
            System.out.printf("| %-5s | %-15s | %-14s | %-10s |%n",
                    u.userId(), u.username(), u.role().name(), u.accountStatus());
        }
        System.out.println(border);
        System.out.println(users.size() + " record(s).");
    }
}
