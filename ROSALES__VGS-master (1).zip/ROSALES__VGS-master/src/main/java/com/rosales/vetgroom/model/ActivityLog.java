package com.rosales.vetgroom.model;

/** One row of the activity_logs audit trail (Java Record). */
public record ActivityLog(int id,
                          int userId,
                          String actionType,
                          String description,
                          String timestamp) { }
