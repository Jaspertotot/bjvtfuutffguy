package com.rosales.vetgroom.dao;

import com.rosales.vetgroom.model.Appointment;
import com.rosales.vetgroom.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDao {

    private static final String SELECT_BASE =
        "SELECT a.appointment_id, o.full_name AS owner_name, a.pet_name, a.service_type, "
      + "a.appointment_date, a.appointment_time, a.appointment_status "
      + "FROM appointments a JOIN pet_owners o ON a.owner_id = o.owner_id ";

    private final ActivityLogDao logDao;

    public AppointmentDao(ActivityLogDao logDao) {
        this.logDao = logDao;
    }

    /**
     * Core business process: a pet owner requests an appointment (status PENDING).
     * Links the logged-in user to a pet_owners record by email, creating it on first use.
     * Returns the new appointment ID, or -1 on failure. Logs APPOINTMENT_CREATED.
     */
    public int createAppointment(User owner, String petName, String petType, String petBreed,
                                 String serviceType, String serviceDescription,
                                 String date, String time) {
        String sql = "INSERT INTO appointments (owner_id, pet_name, pet_type, pet_breed, service_type, "
                   + "service_description, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        int newId = -1;
        try (Connection conn = DatabaseConnection.getConnection()) {
            int ownerId = getOrCreateOwnerId(conn, owner);
            try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, ownerId);
                ps.setString(2, petName);
                ps.setString(3, petType);
                ps.setString(4, petBreed);
                ps.setString(5, serviceType);
                ps.setString(6, serviceDescription);
                ps.setString(7, date);
                ps.setString(8, time);
                if (ps.executeUpdate() == 1) {
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) {
                            newId = keys.getInt(1);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Could not create appointment: " + e.getMessage());
            return -1;
        }
        if (newId > 0) {
            logDao.logAction(owner.userId(), "APPOINTMENT_CREATED",
                    "Created " + serviceType + " appointment #" + newId + " for " + petName
                    + " on " + date + " " + time);
        }
        return newId;
    }

    /** Lifecycle change: updates an appointment's status, assigns the staff member, logs APPOINTMENT_STATUS_UPDATED. */
    public boolean updateAppointmentStatus(int staffUserId, int appointmentId, String newStatus) {
        String selectSql = "SELECT appointment_status FROM appointments WHERE appointment_id = ?";
        String updateSql = "UPDATE appointments SET appointment_status = ?, staff_id = ? WHERE appointment_id = ?";
        String oldStatus;
        try (Connection conn = DatabaseConnection.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                ps.setInt(1, appointmentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        return false;
                    }
                    oldStatus = rs.getString("appointment_status");
                }
            }
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, newStatus.toUpperCase());
                ps.setInt(2, staffUserId);
                ps.setInt(3, appointmentId);
                if (ps.executeUpdate() != 1) {
                    return false;
                }
            }
        } catch (SQLException e) {
            System.err.println("Status update failed: " + e.getMessage());
            return false;
        }
        logDao.logAction(staffUserId, "APPOINTMENT_STATUS_UPDATED",
                "Updated Appointment #" + appointmentId + " status from " + oldStatus + " to " + newStatus.toUpperCase());
        return true;
    }

    /** Appointments belonging to the pet-owner record that shares this user's email. */
    public List<Appointment> getAppointmentsByOwner(User owner) {
        String sql = SELECT_BASE + "WHERE o.email = ? ORDER BY a.appointment_date, a.appointment_time";
        List<Appointment> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, owner.email());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Could not load appointments: " + e.getMessage());
        }
        return list;
    }

    /** Appointments of one service type that are not yet COMPLETED or CANCELLED. */
    public List<Appointment> getOpenAppointmentsByService(String serviceType) {
        String sql = SELECT_BASE + "WHERE a.service_type = ? "
                   + "AND a.appointment_status IN ('PENDING','CONFIRMED','IN_PROGRESS') "
                   + "ORDER BY a.appointment_date, a.appointment_time";
        List<Appointment> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, serviceType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Could not load appointments: " + e.getMessage());
        }
        return list;
    }

    private int getOrCreateOwnerId(Connection conn, User owner) throws SQLException {
        String find = "SELECT owner_id FROM pet_owners WHERE email = ?";
        try (PreparedStatement ps = conn.prepareStatement(find)) {
            ps.setString(1, owner.email());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("owner_id");
                }
            }
        }
        String insert = "INSERT INTO pet_owners (full_name, contact_number, email) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, owner.fullName());
            ps.setString(2, "N/A");
            ps.setString(3, owner.email());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private Appointment map(ResultSet rs) throws SQLException {
        return new Appointment(
            rs.getInt("appointment_id"),
            rs.getString("owner_name"),
            rs.getString("pet_name"),
            rs.getString("service_type"),
            rs.getString("appointment_date"),
            rs.getString("appointment_time"),
            rs.getString("appointment_status"));
    }
}
